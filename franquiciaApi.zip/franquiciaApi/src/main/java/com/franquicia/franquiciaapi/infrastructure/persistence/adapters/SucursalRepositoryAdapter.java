package com.franquicia.franquiciaapi.infrastructure.persistence.adapters;

import com.franquicia.franquiciaapi.application.ports.SucursalRepositoryPort;
import com.franquicia.franquiciaapi.domain.Sucursal;
import com.franquicia.franquiciaapi.domain.Producto;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.FranquiciaEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.SucursalEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.ProductoEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataFranquiciaRepository;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataSucursalRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
public class SucursalRepositoryAdapter implements SucursalRepositoryPort {

    private final SpringDataFranquiciaRepository franquiciaRepository;
    private final SpringDataSucursalRepository sucursalRepository;

    public SucursalRepositoryAdapter(SpringDataFranquiciaRepository franquiciaRepository,
                                       SpringDataSucursalRepository sucursalRepository) {
        this.franquiciaRepository = franquiciaRepository;
        this.sucursalRepository = sucursalRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Sucursal> buscarPorId(Long id) {
        return sucursalRepository.findById(id).map(this::toDomain);
    }

    @Override
    @Transactional
    public Sucursal guardarParaFranquicia(Long franquiciaId, Sucursal sucursal) {
        FranquiciaEntity franquicia = franquiciaRepository.findById(franquiciaId)
                .orElseThrow(() -> new RuntimeException("Franquicia not found: " + franquiciaId));

        SucursalEntity entity = new SucursalEntity();
        entity.setNombre(sucursal.getNombre());
        entity.setFranquicia(franquicia);


        for (Producto p : sucursal.getProductos()) {
            ProductoEntity pe = new ProductoEntity();
            pe.setNombre(p.getNombre());
            pe.setStock(p.getStock());
            pe.setSucursal(entity);
            entity.getProductos().add(pe);
        }

        SucursalEntity saved = sucursalRepository.save(entity);
        return toDomain(saved);
    }

    @Override
    @Transactional
    public Sucursal renombrar(Long id, String nuevoNombre) {
        SucursalEntity entity = sucursalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sucursal not found: " + id));
        entity.setNombre(nuevoNombre);
        return toDomain(sucursalRepository.save(entity));
    }

    private Sucursal toDomain(SucursalEntity entity) {
        List<Producto> productos = entity.getProductos().stream().map(this::toDomainProducto).toList();
        return new Sucursal(entity.getId(), entity.getNombre(), productos);
    }

    private Producto toDomainProducto(ProductoEntity entity) {
        return new Producto(entity.getId(), entity.getNombre(), entity.getStock());
    }
}

