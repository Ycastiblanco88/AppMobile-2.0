package com.franquicia.franquiciaapi.domain;


import java.util.Objects;

public class Producto {
    private final Long id;
    private final String nombre;
    private final int stock;

    public Producto(Long id, String nombre, int stock) {
        this.id = Objects.requireNonNull(id, "id");
        this.nombre = Objects.requireNonNull(nombre, "nombre");
        this.stock = stock;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStock() {
        return stock;
    }

    public Producto renombrar(String nuevoNombre) {
        return new Producto(this.id, nuevoNombre, this.stock);
    }

    public Producto conStock(int nuevoStock) {
        return new Producto(this.id, this.nombre, nuevoStock);
    }
}

