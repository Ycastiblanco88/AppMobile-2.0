package com.franquicia.franquiciaapi.infrastructure.persistence.adapters;


import com.franquicia.franquiciaapi.application.ports.FranquiciaRepositoryPort;
import com.franquicia.franquiciaapi.application.ports.SucursalRepositoryPort;
import com.franquicia.franquiciaapi.application.ports.ProductoRepositoryPort;
import com.franquicia.franquiciaapi.domain.Franquicia;
import com.franquicia.franquiciaapi.domain.Sucursal;
import com.franquicia.franquiciaapi.domain.Producto;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.FranquiciaEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.SucursalEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.ProductoEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataFranquiciaRepository;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataSucursalRepository;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataProductoRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
public class FranquiciaRepositoryAdapter implements FranquiciaRepositoryPort {

    private final SpringDataFranquiciaRepository franquiciaRepository;

    public FranquiciaRepositoryAdapter(SpringDataFranquiciaRepository franquiciaRepository) {
        this.franquiciaRepository = franquiciaRepository;
    }

    @Override
    @Transactional
    public Franquicia guardar(Franquicia franquicia) {
        FranquiciaEntity entity = toEntity(franquicia, new FranquiciaEntity());
        FranquiciaEntity saved = franquiciaRepository.save(entity);
        return toDomain(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Franquicia> buscarPorId(Long id) {
        return franquiciaRepository.findById(id).map(this::toDomain);
    }

    @Override
    @Transactional
    public Franquicia renombrar(Long id, String nuevoNombre) {
        FranquiciaEntity entity = franquiciaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Franquicia not found: " + id));
        entity.setNombre(nuevoNombre);
        FranquiciaEntity saved = franquiciaRepository.save(entity);
        return toDomain(saved);
    }

    private Franquicia toDomain(FranquiciaEntity entity) {
        List<SucursalEntity> sucEntities = entity.getSucursales();
        return new Franquicia(entity.getId(), entity.getNombre(),
                sucEntities.stream().map(this::toDomainSucursal).toList());
    }

    private Sucursal toDomainSucursal(SucursalEntity entity) {
        List<ProductoEntity> prodEntities = entity.getProductos();
        return new Sucursal(entity.getId(), entity.getNombre(),
                prodEntities.stream().map(this::toDomainProducto).toList());
    }

    private Producto toDomainProducto(ProductoEntity entity) {
        return new Producto(entity.getId(), entity.getNombre(), entity.getStock());
    }

    private FranquiciaEntity toEntity(Franquicia franquicia, FranquiciaEntity target) {
        target.setNombre(franquicia.getNombre());
        franquicia.getSucursales().forEach(s -> {
            SucursalEntity se = new SucursalEntity();
            se.setNombre(s.getNombre());
            se.setFranquicia(target);
            s.getProductos().forEach(p -> {
                ProductoEntity pe = new ProductoEntity();
                pe.setNombre(p.getNombre());
                pe.setStock(p.getStock());
                pe.setSucursal(se);
                se.getProductos().add(pe);
            });
            target.getSucursales().add(se);
        });
        return target;
    }
}

