package com.franquicia.franquiciaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FranquiciaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FranquiciaApiApplication.class, args);
    }
}


