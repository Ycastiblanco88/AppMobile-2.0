package com.franquicia.franquiciaapi.infrastructure.persistence.entities;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "franquicias")
public class FranquiciaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre;

    @OneToMany(mappedBy = "franquicia", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SucursalEntity> sucursales = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<SucursalEntity> getSucursales() {
        return sucursales;
    }

    public void addSucursal(SucursalEntity sucursal) {
        sucursales.add(sucursal);
        sucursal.setFranquicia(this);
    }
}

