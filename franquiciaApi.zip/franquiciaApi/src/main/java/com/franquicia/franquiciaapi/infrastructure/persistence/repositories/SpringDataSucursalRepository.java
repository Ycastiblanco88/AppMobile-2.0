package com.franquicia.franquiciaapi.infrastructure.persistence.repositories;

import com.franquicia.franquiciaapi.infrastructure.persistence.entities.SucursalEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SpringDataSucursalRepository extends JpaRepository<SucursalEntity, Long> {

    Optional<SucursalEntity> findByIdAndFranquicia_Id(Long sucursalId, Long franquiciaId);
}

