package com.franquicia.franquiciaapi.domain;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Franquicia {
    private final Long id;
    private final String nombre;
    private final List<Sucursal> sucursales;

    public Franquicia(Long id, String nombre, List<Sucursal> sucursales) {
        this.id = Objects.requireNonNull(id, "id");
        this.nombre = Objects.requireNonNull(nombre, "nombre");
        this.sucursales = sucursales == null ? new ArrayList<>() : new ArrayList<>(sucursales);
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Sucursal> getSucursales() {
        return new ArrayList<>(sucursales);
    }

    public Franquicia renombrar(String nuevoNombre) {
        return new Franquicia(this.id, nuevoNombre, this.sucursales);
    }

    public Franquicia conSucursal(Sucursal sucursal) {
        var nuevo = new ArrayList<>(this.sucursales);
        nuevo.add(Objects.requireNonNull(sucursal));
        return new Franquicia(this.id, this.nombre, nuevo);
    }
}

