package com.franquicia.franquiciaapi.application.ports;


import com.franquicia.franquiciaapi.domain.Producto;
import java.util.List;
import java.util.Optional;

public interface ProductoRepositoryPort {
    Producto guardarParaSucursal(Long sucursalId, Producto producto);
    Optional<Producto> buscarPorId(Long id);
    void eliminarDeSucursal(Long sucursalId, Long productoId);
    Producto actualizarStock(Long sucursalId, Long productoId, int nuevoStock);
    Producto renombrar(Long sucursalId, Long productoId, String nuevoNombre);
    List<Producto> listarPorSucursal(Long sucursalId);
}

