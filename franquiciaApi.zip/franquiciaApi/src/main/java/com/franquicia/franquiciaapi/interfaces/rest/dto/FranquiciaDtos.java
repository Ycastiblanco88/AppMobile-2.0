package com.franquicia.franquiciaapi.interfaces.rest.dto;

import jakarta.validation.constraints.NotBlank;

public class FranquiciaDtos {

    public record CrearFranquiciaRequest(@NotBlank String nombre) {
    }

    public record ActualizarNombreFranquiciaRequest(@NotBlank String nombre) {
    }

    public record FranchiciaResponse(Long id, String nombre) {
    }

    public record MensajeResponse(String message, Long sucursalId, Long productoId) {
    }

}

