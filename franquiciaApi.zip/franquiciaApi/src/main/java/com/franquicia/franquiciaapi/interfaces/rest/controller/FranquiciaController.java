package com.franquicia.franquiciaapi.interfaces.rest.controller;

import com.franquicia.franquiciaapi.application.services.FranquiciaService;
import com.franquicia.franquiciaapi.interfaces.rest.dto.FranquiciaDtos;
import com.franquicia.franquiciaapi.interfaces.rest.dto.FranquiciaSucursalProductoDtos;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

// (MensajeResponse se retornará como Object via mapa)


import java.util.List;

@RestController
@RequestMapping("/api/franquicias")
public class FranquiciaController {

    private final FranquiciaService service;

    public FranquiciaController(FranquiciaService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FranquiciaDtos.FranchiciaResponse crearFranquicia(@Valid @RequestBody FranquiciaDtos.CrearFranquiciaRequest req) {
        var f = service.crearFranquicia(req.nombre());
        return new FranquiciaDtos.FranchiciaResponse(f.getId(), f.getNombre());
    }

    @PutMapping("/{franquiciaId}/nombre")
    public FranquiciaDtos.FranchiciaResponse actualizarNombreFranquicia(
            @PathVariable Long franquiciaId,
            @Valid @RequestBody FranquiciaDtos.ActualizarNombreFranquiciaRequest req
    ) {
        var f = service.actualizarNombreFranquicia(franquiciaId, req.nombre());
        return new FranquiciaDtos.FranchiciaResponse(f.getId(), f.getNombre());
    }

    @PostMapping("/{franquiciaId}/sucursales")
    @ResponseStatus(HttpStatus.CREATED)
    public FranquiciaSucursalProductoDtos.SucursalResponse agregarSucursal(
            @PathVariable Long franquiciaId,
            @Valid @RequestBody FranquiciaSucursalProductoDtos.CrearSucursalRequest req
    ) {
        var s = service.agregarSucursal(franquiciaId, req.nombre());
        return new FranquiciaSucursalProductoDtos.SucursalResponse(s.getId(), s.getNombre());
    }

    @PutMapping("/sucursales/{sucursalId}/nombre")
    public FranquiciaSucursalProductoDtos.SucursalResponse actualizarNombreSucursal(
            @PathVariable Long sucursalId,
            @RequestParam Long franquiciaId,
            @Valid @RequestBody FranquiciaSucursalProductoDtos.ActualizarNombreSucursalRequest req
    ) {

        var s = service.actualizarNombreSucursal(sucursalId, franquiciaId, req.nombre());
        return new FranquiciaSucursalProductoDtos.SucursalResponse(s.getId(), s.getNombre());
    }

    @PostMapping("/sucursales/{sucursalId}/productos")
    @ResponseStatus(HttpStatus.CREATED)
    public FranquiciaSucursalProductoDtos.ProductoResponse agregarProducto(
            @PathVariable Long sucursalId,
            @Valid @RequestBody FranquiciaSucursalProductoDtos.CrearProductoRequest req
    ) {
        var p = service.agregarProducto(sucursalId, req.nombre(), req.stock());
        return new FranquiciaSucursalProductoDtos.ProductoResponse(p.getId(), p.getNombre(), p.getStock());
    }

    @DeleteMapping("/sucursales/{sucursalId}/productos/{productoId}")
public Object eliminarProducto(
            @PathVariable Long sucursalId,
            @PathVariable Long productoId
    ) {
        service.eliminarProducto(sucursalId, productoId);
        return new FranquiciaDtos.MensajeResponse(
                "Producto eliminado correctamente",
                sucursalId,
                productoId
        );
    }


    @PutMapping("/sucursales/{sucursalId}/productos/{productoId}/stock")
    public FranquiciaSucursalProductoDtos.ProductoResponse modificarStockProducto(
            @PathVariable Long sucursalId,
            @PathVariable Long productoId,
            @Valid @RequestBody FranquiciaSucursalProductoDtos.ModificarStockRequest req
    ) {
        var p = service.modificarStock(sucursalId, productoId, req.stock());
        return new FranquiciaSucursalProductoDtos.ProductoResponse(p.getId(), p.getNombre(), p.getStock());
    }

    @PutMapping("/sucursales/{sucursalId}/productos/{productoId}/nombre")
    public FranquiciaSucursalProductoDtos.ProductoResponse actualizarNombreProducto(
            @PathVariable Long sucursalId,
            @PathVariable Long productoId,
            @Valid @RequestBody FranquiciaSucursalProductoDtos.ActualizarNombreProductoRequest req
    ) {
        var p = service.actualizarNombreProducto(sucursalId, productoId, req.nombre());
        return new FranquiciaSucursalProductoDtos.ProductoResponse(p.getId(), p.getNombre(), p.getStock());
    }

    @GetMapping("/{franquiciaId}/productos/top-stock-por-sucursal")
    public List<FranquiciaSucursalProductoDtos.ProductoMayorStockResponse> topProductoPorSucursal(
            @PathVariable Long franquiciaId
    ) {
        return service.productoConMayorStockPorSucursal(franquiciaId).stream()
                .map(m -> new FranquiciaSucursalProductoDtos.ProductoMayorStockResponse(
                        m.franquiciaId(), m.franquiciaNombre(),
                        m.sucursalId(), m.sucursalNombre(),
                        m.productoId(), m.productoNombre(), m.stock()
                ))
                .toList();
    }
}

