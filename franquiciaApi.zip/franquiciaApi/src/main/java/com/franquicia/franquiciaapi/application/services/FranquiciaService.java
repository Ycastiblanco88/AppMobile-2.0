 package com.franquicia.franquiciaapi.application.services;


import com.franquicia.franquiciaapi.application.ports.FranquiciaRepositoryPort;
import com.franquicia.franquiciaapi.application.ports.ProductoRepositoryPort;
import com.franquicia.franquiciaapi.application.ports.SucursalRepositoryPort;
import com.franquicia.franquiciaapi.domain.Franquicia;
import com.franquicia.franquiciaapi.domain.Producto;
import com.franquicia.franquiciaapi.domain.Sucursal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

@Service
public class FranquiciaService {

    private final FranquiciaRepositoryPort franquiciaRepository;
    private final SucursalRepositoryPort sucursalRepository;
    private final ProductoRepositoryPort productoRepository;

    public FranquiciaService(FranquiciaRepositoryPort franquiciaRepository,
                              SucursalRepositoryPort sucursalRepository,
                              ProductoRepositoryPort productoRepository) {
        this.franquiciaRepository = franquiciaRepository;
        this.sucursalRepository = sucursalRepository;
        this.productoRepository = productoRepository;
    }

    @Transactional
    public Franquicia crearFranquicia(String nombre) {
        return franquiciaRepository.guardar(new Franquicia(0L, nombre, List.of()));
    }

    @Transactional
    public Franquicia actualizarNombreFranquicia(Long id, String nuevoNombre) {
        return franquiciaRepository.renombrar(id, nuevoNombre);
    }

    @Transactional
    public Sucursal agregarSucursal(Long franquiciaId, String nombreSucursal) {
        Sucursal sucursal = new Sucursal(0L, nombreSucursal, List.of());
        return sucursalRepository.guardarParaFranquicia(franquiciaId, sucursal);
    }

    @Transactional
    public Sucursal actualizarNombreSucursal(Long sucursalId, Long franquiciaId, String nuevoNombre) {
        return sucursalRepository.renombrar(sucursalId, nuevoNombre);
    }

    @Transactional
    public Producto agregarProducto(Long sucursalId, String nombreProducto, int stock) {
        Producto producto = new Producto(0L, nombreProducto, stock);
        return productoRepository.guardarParaSucursal(sucursalId, producto);
    }

    @Transactional
    public void eliminarProducto(Long sucursalId, Long productoId) {
        productoRepository.eliminarDeSucursal(sucursalId, productoId);
    }

    @Transactional
    public Producto modificarStock(Long sucursalId, Long productoId, int nuevoStock) {
        return productoRepository.actualizarStock(sucursalId, productoId, nuevoStock);
    }

    @Transactional
    public Producto actualizarNombreProducto(Long sucursalId, Long productoId, String nuevoNombre) {
        return productoRepository.renombrar(sucursalId, productoId, nuevoNombre);
    }

    @Transactional(readOnly = true)
    public List<ProductoConSucursal> productoConMayorStockPorSucursal(Long franquiciaId) {
        Franquicia franquicia = franquiciaRepository.buscarPorId(franquiciaId)
                .orElseThrow(() -> new RuntimeException("Franquicia not found: " + franquiciaId));


        return franquicia.getSucursales().stream()
                .map(s -> productoRepository.listarPorSucursal(s.getId())
                        .stream()
                        .max(Comparator.comparingInt(Producto::getStock))
                        .map(mayor -> new ProductoConSucursal(
                                franquicia.getId(),
                                franquicia.getNombre(),
                                s.getId(),
                                s.getNombre(),
                                mayor.getId(),
                                mayor.getNombre(),
                                mayor.getStock()
                        ))
                        .orElse(null))
                .filter(Objects::nonNull)
                .toList();
    }

    public record ProductoConSucursal(Long franquiciaId,
                                        String franquiciaNombre,
                                        Long sucursalId,
                                        String sucursalNombre,
                                        Long productoId,
                                        String productoNombre,
                                        int stock) {
    }
}

