package com.franquicia.franquiciaapi.infrastructure.persistence.repositories;

import com.franquicia.franquiciaapi.infrastructure.persistence.entities.FranquiciaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataFranquiciaRepository extends JpaRepository<FranquiciaEntity, Long> {
}

