package com.franquicia.franquiciaapi.infrastructure.persistence.adapters;

import com.franquicia.franquiciaapi.application.ports.ProductoRepositoryPort;
import com.franquicia.franquiciaapi.domain.Producto;
import com.franquicia.franquiciaapi.domain.Sucursal;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.ProductoEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.entities.SucursalEntity;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataProductoRepository;
import com.franquicia.franquiciaapi.infrastructure.persistence.repositories.SpringDataSucursalRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
public class ProductoRepositoryAdapter implements ProductoRepositoryPort {

    private final SpringDataProductoRepository productoRepository;
    private final SpringDataSucursalRepository sucursalRepository;

    public ProductoRepositoryAdapter(SpringDataProductoRepository productoRepository,
                                     SpringDataSucursalRepository sucursalRepository) {
        this.productoRepository = productoRepository;
        this.sucursalRepository = sucursalRepository;
    }

    @Override
    @Transactional
    public Producto guardarParaSucursal(Long sucursalId, Producto producto) {
        SucursalEntity sucursal = sucursalRepository.findById(sucursalId)
                .orElseThrow(() -> new RuntimeException("Sucursal not found: " + sucursalId));

        ProductoEntity entity = new ProductoEntity();
        entity.setNombre(producto.getNombre());
        entity.setStock(producto.getStock());
        entity.setSucursal(sucursal);

        ProductoEntity saved = productoRepository.save(entity);
        return toDomain(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Producto> buscarPorId(Long id) {
        return productoRepository.findById(id).map(this::toDomain);
    }

    @Override
    @Transactional
    public void eliminarDeSucursal(Long sucursalId, Long productoId) {
        ProductoEntity entity = productoRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto not found: " + productoId));

        if (!entity.getSucursal().getId().equals(sucursalId)) {
            throw new RuntimeException("Producto no pertenece a la sucursal: " + sucursalId);
        }

        productoRepository.delete(entity);
    }

    @Override
    @Transactional
    public Producto actualizarStock(Long sucursalId, Long productoId, int nuevoStock) {
        ProductoEntity entity = productoRepository.findByIdAndSucursal_Id(productoId, sucursalId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado para sucursal"));
        entity.setStock(nuevoStock);
        return toDomain(productoRepository.save(entity));
    }

    @Override
    @Transactional
    public Producto renombrar(Long sucursalId, Long productoId, String nuevoNombre) {
        ProductoEntity entity = productoRepository.findByIdAndSucursal_Id(productoId, sucursalId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado para sucursal"));
        entity.setNombre(nuevoNombre);
        return toDomain(productoRepository.save(entity));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Producto> listarPorSucursal(Long sucursalId) {
        return productoRepository.findAllBySucursal_Id(sucursalId).stream().map(this::toDomain).toList();
    }

    private Producto toDomain(ProductoEntity entity) {
        return new Producto(entity.getId(), entity.getNombre(), entity.getStock());
    }
}

