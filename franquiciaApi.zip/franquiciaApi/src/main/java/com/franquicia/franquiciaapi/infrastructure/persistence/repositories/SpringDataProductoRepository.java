package com.franquicia.franquiciaapi.infrastructure.persistence.repositories;

import com.franquicia.franquiciaapi.infrastructure.persistence.entities.ProductoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SpringDataProductoRepository extends JpaRepository<ProductoEntity, Long> {

    Optional<ProductoEntity> findByIdAndSucursal_Id(Long productoId, Long sucursalId);

    List<ProductoEntity> findAllBySucursal_Id(Long sucursalId);
}

