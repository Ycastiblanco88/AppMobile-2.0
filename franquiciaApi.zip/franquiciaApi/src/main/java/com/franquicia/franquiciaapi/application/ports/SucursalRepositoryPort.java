package com.franquicia.franquiciaapi.application.ports;


import com.franquicia.franquiciaapi.domain.Sucursal;
import java.util.Optional;

public interface SucursalRepositoryPort {
    Optional<Sucursal> buscarPorId(Long id);
    Sucursal guardarParaFranquicia(Long franquiciaId, Sucursal sucursal);
    Sucursal renombrar(Long id, String nuevoNombre);
}

