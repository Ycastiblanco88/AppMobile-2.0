package com.franquicia.franquiciaapi.interfaces.rest.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

import java.util.List;

public class FranquiciaSucursalProductoDtos {

    public record CrearSucursalRequest(@NotBlank String nombre) {
    }

    public record ActualizarNombreSucursalRequest(@NotBlank String nombre) {
    }

    public record SucursalResponse(Long id, String nombre) {
    }

    public record CrearProductoRequest(@NotBlank String nombre, @Min(0) int stock) {
    }

    public record ModificarStockRequest(@Min(0) int stock) {
    }

    public record ActualizarNombreProductoRequest(@NotBlank String nombre) {
    }

    public record ProductoResponse(Long id, String nombre, int stock) {
    }

    public record ProductoMayorStockResponse(
            Long franquiciaId,
            String franquiciaNombre,
            Long sucursalId,
            String sucursalNombre,
            Long productoId,
            String productoNombre,
            int stock
    ) {
    }
}

