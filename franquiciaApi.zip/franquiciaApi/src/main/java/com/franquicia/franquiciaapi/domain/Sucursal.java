package com.franquicia.franquiciaapi.domain;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Sucursal {
    private final Long id;
    private final String nombre;
    private final List<Producto> productos;

    public Sucursal(Long id, String nombre, List<Producto> productos) {
        this.id = Objects.requireNonNull(id, "id");
        this.nombre = Objects.requireNonNull(nombre, "nombre");
        this.productos = productos == null ? new ArrayList<>() : new ArrayList<>(productos);
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Producto> getProductos() {
        return new ArrayList<>(productos);
    }

    public Sucursal renombrar(String nuevoNombre) {
        return new Sucursal(this.id, nuevoNombre, this.productos);
    }

    public Sucursal conProducto(Producto producto) {
        var nuevo = new ArrayList<>(this.productos);
        nuevo.add(Objects.requireNonNull(producto));
        return new Sucursal(this.id, this.nombre, nuevo);
    }

    public Sucursal conStockActualizado(Long productoId, int nuevoStock) {
        var nuevo = new ArrayList<Producto>();
        for (Producto p : this.productos) {
            if (p.getId().equals(productoId)) {
                nuevo.add(p.conStock(nuevoStock));
            } else {
                nuevo.add(p);
            }
        }
        return new Sucursal(this.id, this.nombre, nuevo);
    }

    public Sucursal sinProducto(Long productoId) {
        var nuevo = new ArrayList<Producto>();
        for (Producto p : this.productos) {
            if (!p.getId().equals(productoId)) {
                nuevo.add(p);
            }
        }
        return new Sucursal(this.id, this.nombre, nuevo);
    }

    public Producto productoConMayorStock() {
        if (productos.isEmpty()) return null;
        return productos.stream().max((a, b) -> Integer.compare(a.getStock(), b.getStock())).orElse(null);
    }
}

