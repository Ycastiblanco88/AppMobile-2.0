package com.franquicia.franquiciaapi.application.ports;


import com.franquicia.franquiciaapi.domain.Franquicia;
import java.util.List;
import java.util.Optional;

public interface FranquiciaRepositoryPort {
    Franquicia guardar(Franquicia franquicia);
    Optional<Franquicia> buscarPorId(Long id);
    Franquicia renombrar(Long id, String nuevoNombre);
}

