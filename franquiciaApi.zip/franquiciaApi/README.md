# FranquiciaApi

API REST para manejar **franquicias**, **sucursales** y **productos** usando **Spring Boot** + persistencia **H2**.

## Endpoints (base)
- **Base URL**: `http://localhost:8080`

### Franquicias
- `POST   /api/franquicias` Body: `{ "nombre": "..." }`
- `PUT    /api/franquicias/{franquiciaId}/nombre` Body: `{ "nombre": "..." }`

### Sucursales
- `POST   /api/franquicias/{franquiciaId}/sucursales` Body: `{ "nombre": "..." }`
- `PUT    /api/franquicias/sucursales/{sucursalId}/nombre?franquiciaId={id}` Body: `{ "nombre": "..." }`

### Productos (por sucursal)
- `POST   /api/franquicias/sucursales/{sucursalId}/productos` Body: `{ "nombre": "...", "stock": 10 }`
- `PUT    /api/franquicias/sucursales/{sucursalId}/productos/{productoId}/stock` Body: `{ "stock": 20 }`
- `PUT    /api/franquicias/sucursales/{sucursalId}/productos/{productoId}/nombre` Body: `{ "nombre": "Nuevo" }`
- `DELETE /api/franquicias/sucursales/{sucursalId}/productos/{productoId}`

### Reporte: producto con mayor stock por sucursal (para una franquicia)
- `GET /api/franquicias/{franquiciaId}/productos/top-stock-por-sucursal`

Devuelve un listado donde cada elemento indica:
- franquicia (id/nombre)
- sucursal (id/nombre)
- producto (id/nombre) y su `stock`

## Despliegue local
### Requisitos
- Java 17
- Maven

### Ejecutar
En la carpeta del proyecto:
```bash
mvn spring-boot:run
```
Luego abre:
- H2 Console: `http://localhost:8080/h2-console`
  - **JDBC URL**: `jdbc:h2:mem:franquiciasdb`
  - **User**: `sa`
  - **Password**: *(vacío)*

## Probar con Postman
1. `POST http://localhost:8080/api/franquicias` ejemplo:
   ```json
   {"nombre":"Franquicia Centro"}
   ```
2. Copia el `id` devuelto y crea una sucursal:
   ```json
   {"nombre":"Sucursal 1"}
   ```
3. Copia el `id` de la sucursal y agrega productos:
   ```json
   {"nombre":"Producto A","stock": 5}
   ```
4. Llama:
   `GET /api/franquicias/{franquiciaId}/productos/top-stock-por-sucursal`

## Manejo de errores
La API devuelve `ApiErrorResponse` en caso de validación o recursos no encontrados.

